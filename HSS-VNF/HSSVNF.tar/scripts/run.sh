#!/usr/bin/env bash

nohup tshark -i eth0 -i eth1 -w /tmp/hss_check_run.pcap 2>&1 > /dev/null
nohup /openair-hss/bin/oai_hss -j /openair-mme/etc/hss_rel14.json --reloadkey true > hss_check_run.log 2>&1

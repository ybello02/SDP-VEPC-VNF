#!/bin/bash

ping localhost

#!/usr/bin/env bash

ping localhost
